package com.iqbalfauzi.watchon.ui.listener

import android.view.View

/**
 * Created by Iqbal Fauzi on 10:54 24/10/19
 */
interface OnItemClickListener {
    fun onItemClick(itemView: View, position: Int)
}