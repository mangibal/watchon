package com.iqbalfauzi.watchon.data.model

/**
 * Created by Iqbal Fauzi on 15:50 14/11/19
 */
data class Dates(
    val maximum: String,
    val minimum: String
)