package com.iqbalfauzi.watchon.data.repository.local

open class LocalRepository